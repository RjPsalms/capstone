import type { Modifier } from "../types";
export default function mergeByName(modifiers: Array<Partial<Modifier<any, any>>>): Array<Partial<Modifier<any, any>>>;
