import type { Window } from "../types";
export default function getWindowScroll(node: Node | Window): {
    scrollLeft: any;
    scrollTop: any;
};
