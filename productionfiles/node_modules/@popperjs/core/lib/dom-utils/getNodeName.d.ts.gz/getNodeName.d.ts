import type { Window } from "../types";
export default function getNodeName(element: (Node | null | undefined) | Window): string | null | undefined;
